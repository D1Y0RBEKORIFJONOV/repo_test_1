## Uy vazifa

> Mutekslar bilan bir vaqtda `map` ni saqlaydigan `Go` dasturini amalga oshiring.
Dastur bir nechta `goroutine`larga bir vaqtning o'zida xaritadan yozuvlarni xavfsiz o'qish, yozish va o'chirish imkonini berishi kerak.





