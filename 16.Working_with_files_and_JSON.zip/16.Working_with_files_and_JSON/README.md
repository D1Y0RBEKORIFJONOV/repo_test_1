## Uy vazifalar

### 1
* ### Bitta fayl tarkibini boshqa faylga ko'chiradigan dastur yozing. (ishora: `io.Copy` method)

### 2
* ### Berilgan fayl nomiga joriy sana va vaqtni qo‘shish orqali uning zaxira nusxasini (backup) yaratuvchi dastur yozing.
* ### Misol: `file.txt` => `file_backup_2024-04-17_114819.txt`
* ### Fayl ihtiyoriy korinishida

