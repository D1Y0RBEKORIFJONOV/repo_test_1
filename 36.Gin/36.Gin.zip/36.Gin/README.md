## Uy vazifa

1. ### Bugungi `albums` resource ga CRUD (CREATE, READ, UPDATE, DELETE) operatsiyalari uchun RESTful API serverini ishlab chiqing va Gin framework qollang. 
2. ### Faqatgina ma'lumotla Postgres db da bolishi kerak. Yangi `albums` degan jadval yarating
































