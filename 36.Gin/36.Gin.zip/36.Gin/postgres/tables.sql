CREATE TABLE IF NOT EXISTS album(
    id VARCHAR(55),
    title VARCHAR(55),
    artist VARCHAR(255),
    price FLOAT
)
