## Uy vazifa

1. #### Demo database ga `Go` o'rqali ulaning:
2. #### `Products` jadvaliga yangi ihtiyoriy mahsulot va uning categoriyasining qoching
3. #### Usha mahsulotti va uning categoriyasini bilan qaytaring
4. #### Mahsulotga yangi narx qoying
5. #### Yangilangan narxi bilan categoriyasini qaytaring
6. #### Yangi mahsulotti o'chirib tashlang
7. #### Har `SQL` bayonoti bir transaction ichida bo'lishi lozim  




























