## Uy vazifa

* ###` Fayl I/O (kiritish-chiqarish)` operatsiyalarini (masalan, fayllardan o'qish, fayllarga yozish) bajaradigan dasturni ishlab chiqish.
* ### Fayl operatsiyalari bajarilishini nazorat qilish va vaqt tugashi yoki bekor qilishni amalga oshirish uchun `context.Context` dan foydalaning.
* ### `defer` bayonotini va `context` ni bekor qilish signallari bilan `error`larni qayta ishlash va resurslarni tozalashini samalga oshiring.












