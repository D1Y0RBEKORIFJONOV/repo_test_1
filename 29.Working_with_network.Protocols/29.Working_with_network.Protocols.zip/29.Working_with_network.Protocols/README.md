## Uy vazifa

1. #### [PostresSQL tutorials](https://www.postgresqltutorial.com/postgresql-indexes/postgresql-create-index/) web-sayidagi `POSTGRESQL INDEXES` bo'limi ohirgacha ko'rib chiqing
2. ### `people` nomli jadval yarating, uning ichida `id`, `first_name` va `last_name` digan ustunlar mavjud bosin
3. ### [script](https://www.postgresqltutorial.com/wp-content/uploads/2019/01/Script-to-load-10000-names.txt) commandasini bajaring
4. ### `Adrian` nomli shaxsni filterlab `EXPLAIN ANALYZE` bayonoti bilan qacha vaqtda qaytarishini ko'ring
5. ### Endi `first_name` ga index yarating
6. ### Yana bir bor 4 raqamdegi qadamni amalga oshiring. Natijasini nima uchun o'zgarganligini yozib keting
7. ### Yaratilgan index ni ochirib tashlang
8. ### Yangi index ham `first_name` ham `last_name` ustunlarni oladigan indexni yarating
9. ### Ismi `Adrian` va familiyasi `Gross` degan shaxsni filterlab chiqaring. `EXPLAIN ANALYZE` ishlatganda qanday natija bo'ldi? Endi birinchi familiyasi `Gross` keyin ismi `Adrian` digan filter ni yo'zing. Natija o'zgardimi? Javobini yo'zing


























