## Uy vazifa

1. ### Bugungi darsni qollanmadegi foyladi havolalarni ko'rib chiqing 
2. ### URL-addressni kirish sifatida qabul qiladigan va uning `schema`, `host`, `path`, `query params` va `fragment` ni ajratib olish uchun uni tahlil qiladigan Go dasturini yozing. Har bir komponentni alohida chop eting. (ishora: net/url packet)
3. ### Alohida `query parameter`larni ularning qiymatlari bilan birga ajratib oling va chop etish uchun oldingi dasturni kengaytiring.
4. ### Kirish sifatida string ni qabul qiladigan va uning URL addressi to'g'ri yoki yo'qligini tekshiradigan funktsiyani yozing. Agar kirish satri to'g'ri URL manzilini bildirsa, true qiymatini qaytaring, aks holda false.



























