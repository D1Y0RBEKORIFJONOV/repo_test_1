## Uy vazifa

1. ### O'zingizni database da `large_dataset` digan jadval yarating
2. ### Ichida `id` va `generated` digan int type dagi ustunlar qoying
3. ### generate_series digan postgresql function o'rqali 1 dan 10 milliongacha sonlarni `large_dataset` jadvaliga qoshing
4. ### `Go` da usha jadvaldegi `id` va `generated` ustunlari structga scan qivoling
5. ### Ushbu `SQL` ga context timeout 2 ga teng holda `Go` dan yuborilsin
6. ### Qanaqa natijaga chiqti? Timeout ni kopaytirib yoki kamaytib korin. Qanaqa o'zgarish bo'ldi?



























