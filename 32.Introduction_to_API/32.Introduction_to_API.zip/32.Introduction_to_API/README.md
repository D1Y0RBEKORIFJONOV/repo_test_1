## Uy vazifa

1. ### PostgreSQL da bir vaqtining o'zida insert, select va update bajaradigan Go dastur tuzing
2. ### `large_dataset` jadvaliga qo'llang
3. ### Har bir operatsiya o'z goroutine da bajarilishi kerak
4. ### Bir nechta goroutinelar ni ishlatish uchun `errorgroup` package ni amalga oshiring
5. ### Umimiy `context` timeout ham ishlating




























