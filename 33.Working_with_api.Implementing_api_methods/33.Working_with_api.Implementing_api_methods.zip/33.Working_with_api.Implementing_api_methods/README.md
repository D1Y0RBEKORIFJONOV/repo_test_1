## Uy vazifa

1. ### `Go` da faylni mijozdan serverga `TCP` ulanishi orqali yuboradigan dasturni yozing. 
2. ### Bir vaqtning o'zida bir nechta fayllarni yuborish uchun imkoniyatni yarating.
3. ### Faylarni `path` ni terminaldan olib ishlatadigan qiling





























