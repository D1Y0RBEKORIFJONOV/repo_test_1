## Uy vazifa

> Bir vaqtning o'zida bir nechta vazifalarni bajaradigan va natijalarni `fan-in` pattern dan foydalangan holda 
birlashtiradigan `Go` dasturini amalga oshiring. <br>
Turli kanallardan natijalarni olish va barcha vazifalarni bajarishni sinxronlashtirish uchun `WaitGroup`-ni sinxronlashtirish uchun `select` bayonotidan foydalaning.
> 